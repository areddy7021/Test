package com.uhc.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Immutable
@Table(name = "stg_preferences_topic" , schema = "eim")
public class Eligibility {


}
