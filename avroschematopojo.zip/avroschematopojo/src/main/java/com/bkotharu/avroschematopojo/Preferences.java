package com.bkotharu.avroschematopojo;

public class Preferences {

	private String id;

	private String catCd;

	private String topicCd;

	private String propCd;

	private String selectEffDt;

	private String prefCd;

	private String recStatus;

	private String msgStatus;

	private String srcCreatBy;

	private String srcCreatDt;

	private String srcLstModBy;

	private String getSrcLstModDt;

	private String creatBy;

	private String creatDt;

	private String lastModBy;

	private String lastModDt;

	private String srcSys;

	private String permission;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCatCd() {
		return catCd;
	}

	public void setCatCd(String catCd) {
		this.catCd = catCd;
	}

	public String getTopicCd() {
		return topicCd;
	}

	public void setTopicCd(String topicCd) {
		this.topicCd = topicCd;
	}

	public String getPropCd() {
		return propCd;
	}

	public void setPropCd(String propCd) {
		this.propCd = propCd;
	}

	public String getSelectEffDt() {
		return selectEffDt;
	}

	public void setSelectEffDt(String selectEffDt) {
		this.selectEffDt = selectEffDt;
	}

	public String getPrefCd() {
		return prefCd;
	}

	public void setPrefCd(String prefCd) {
		this.prefCd = prefCd;
	}

	public String getRecStatus() {
		return recStatus;
	}

	public void setRecStatus(String recStatus) {
		this.recStatus = recStatus;
	}

	public String getMsgStatus() {
		return msgStatus;
	}

	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}

	public String getSrcCreatBy() {
		return srcCreatBy;
	}

	public void setSrcCreatBy(String srcCreatBy) {
		this.srcCreatBy = srcCreatBy;
	}

	public String getSrcCreatDt() {
		return srcCreatDt;
	}

	public void setSrcCreatDt(String srcCreatDt) {
		this.srcCreatDt = srcCreatDt;
	}

	public String getSrcLstModBy() {
		return srcLstModBy;
	}

	public void setSrcLstModBy(String srcLstModBy) {
		this.srcLstModBy = srcLstModBy;
	}

	public String getGetSrcLstModDt() {
		return getSrcLstModDt;
	}

	public void setGetSrcLstModDt(String getSrcLstModDt) {
		this.getSrcLstModDt = getSrcLstModDt;
	}

	public String getCreatBy() {
		return creatBy;
	}

	public void setCreatBy(String creatBy) {
		this.creatBy = creatBy;
	}

	public String getCreatDt() {
		return creatDt;
	}

	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}

	public String getLastModBy() {
		return lastModBy;
	}

	public void setLastModBy(String lastModBy) {
		this.lastModBy = lastModBy;
	}

	public String getLastModDt() {
		return lastModDt;
	}

	public void setLastModDt(String lastModDt) {
		this.lastModDt = lastModDt;
	}

	public String getSrcSys() {
		return srcSys;
	}

	public void setSrcSys(String srcSys) {
		this.srcSys = srcSys;
	}

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}

}
