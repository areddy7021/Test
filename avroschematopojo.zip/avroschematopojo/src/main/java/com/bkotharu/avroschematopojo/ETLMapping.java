package com.bkotharu.avroschematopojo;

import com.optum.exts.individual.preference.selection.model.IndividualPreferenceSelection;
import com.optum.exts.individual.preference.selection.model.audit;
import com.optum.exts.individual.preference.selection.model.preferenceSelection;

public class ETLMapping {

	public void map() {
		IndividualPreferenceSelection selection = new IndividualPreferenceSelection();
		Preferences preferences = new Preferences();

		selection.setIndividualIdentifier(preferences.getId());
		selection.setIndividualSourceSystemCode(preferences.getSrcSys() == null ? "COMPASS": preferences.getSrcSys());

		audit audit1 = audit.newBuilder().setCreateUserIdentifier(preferences.getCreatBy())
				.setCreateDatetime(Long.getLong(preferences.getCreatDt()))
				.setUpdateUserIdentifier(preferences.getLastModBy())
				.setUpdateDatetime(Long.valueOf(preferences.getLastModDt()))
				.setSourceSystemCreateUserIdentifier(preferences.getSrcCreatBy())
				.setSourceSystemCreateDatetime(Long.valueOf(preferences.getSrcCreatDt()))
				.setSourceSystemUpdateUserIdentifier(preferences.getSrcLstModBy())
				.setSourceSystemUpdateDatetime(Long.valueOf(preferences.getGetSrcLstModDt()))
				.setRecordStatusCode(preferences.getRecStatus()).build();

		selection.setAudit(audit1);
		
		preferenceSelection preferenceSelection1 = preferenceSelection.newBuilder()
				.build();
		
		selection.setPreferenceSelection(null);
	}

	public static void main(String[] args) {
		ETLMapping etlMapping = new ETLMapping();

		etlMapping.map();
	}

}
