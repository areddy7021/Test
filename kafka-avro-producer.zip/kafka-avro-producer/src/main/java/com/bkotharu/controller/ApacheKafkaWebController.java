package com.bkotharu.controller;

import com.bkotharu.model.Preferences;
import com.bkotharu.schema.model.preferences.IndividualPreferenceSelection;
import com.bkotharu.service.KafkaSender;
import com.bkotharuutils.Mapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(value = "/javainuse-kafka/")
public class ApacheKafkaWebController {

	@Autowired
	KafkaSender kafkaSender;
	
	@PostMapping(value = "/publish")
	public String preferencesProducer(@RequestParam("message") String message, @RequestBody Preferences preferences)
			throws JsonProcessingException, ParseException {
		ObjectMapper mapper = new ObjectMapper();
		 
		IndividualPreferenceSelection individualPreferenceSelection = Mapper.getMapping(preferences);
		System.out.println(individualPreferenceSelection.toString());
		kafkaSender.send(preferences.getId(), individualPreferenceSelection.toString());
		return "Message sent to the Kafka Topic NewTopic Successfully";
	}

	/*
	 * @GetMapping(value = "/publish") public String
	 * preferencesProducer(@RequestParam("message") String message) throws
	 * JsonProcessingException, ParseException { ObjectMapper mapper = new
	 * ObjectMapper();
	 * 
	 * Preferences preferences = new Preferences();
	 * preferences.setCreatDt("2022-09-12");
	 * preferences.setGetSrcLstModDt("2022-09-12");
	 * preferences.setLastModDt("2022-09-12");
	 * preferences.setSrcCreatDt("2022-09-12");
	 * preferences.setGetSrcLstModDt("2022-09-12");
	 * preferences.setSelectEffDt("2022-09-12"); IndividualPreferenceSelection
	 * individualPreferenceSelection = Mapper.getMapping(preferences);
	 * System.out.println(individualPreferenceSelection.toString());
	 * kafkaSender.send("", individualPreferenceSelection.toString()); return
	 * "Message sent to the Kafka Topic NewTopic Successfully"; }
	 */

}
